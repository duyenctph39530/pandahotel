<?php
?>
<tr>
    <th></th>
    <th><?php esc_html_e( 'Product', 'wcbt' ); ?></th>
    <th><?php esc_html_e( 'Price', 'wcbt' ); ?></th>
    <th><?php esc_html_e( 'Add to cart', 'wcbt' ); ?></th>
</tr>

