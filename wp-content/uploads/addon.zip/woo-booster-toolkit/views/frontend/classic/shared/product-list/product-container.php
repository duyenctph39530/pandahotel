<?php
if (! isset($data)) {
    return;
}

?>
<div class="<?php echo esc_attr(apply_filters('wcbt/filter/product-list/product-container/class', 'wcbt-product-container')); ?>"
     data-grid-col="1">
    <div class="wcbt-wave-loading">
    </div>
</div>
