<?php
?>
<div class="<?php echo esc_attr( apply_filters( 'wcbt/filter/pagination-wrapper/class', 'wcbt-pagination-wrapper' ) ); ?>">
	<div class="wcbt-from-to">

	</div>
	<div class="wcbt-pagination">

	</div>
</div>
