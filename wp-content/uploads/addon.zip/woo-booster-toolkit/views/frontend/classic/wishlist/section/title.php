<?php
?>
<div class="wcbt-container">
    <h1 class="wcbt-wishlist-title"><?php the_title(); ?></h1>
</div>
