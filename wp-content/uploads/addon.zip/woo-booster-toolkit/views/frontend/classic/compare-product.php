<?php
/**
 * Template for displaying content of compare product page.
 */
use WCBT\Helpers\Template;

Template::instance()->get_frontend_template_type_classic('compare-product/content.php');
