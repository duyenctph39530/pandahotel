<?php
if (! isset($data)) {
    return;
}
?>

<div class="wcbt-sale-notice-wrapper">
</div>

