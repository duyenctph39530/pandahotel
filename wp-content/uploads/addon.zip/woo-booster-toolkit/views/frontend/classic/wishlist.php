<?php
/**
 * Template for displaying content of wishlist page
 */

use WCBT\Helpers\Template;

Template::instance(true)->get_frontend_template_type_classic('wishlist/content.php');

