<?php
return apply_filters(
	'wcbt/filter/config/widgets/product-filter',
	array()
);
