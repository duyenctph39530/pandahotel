<?php

namespace WCBT\Helpers\Fields;

/**
 * Class WPEditor
 * @package WCBT\Helpers\AbstractForm
 */
class WPEditor extends AbstractField
{
    public $path_view = 'fields/wp-editor.php';
    public function __construct()
    {
    }
}
