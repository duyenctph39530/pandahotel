<?php

namespace WCBT\Helpers\Fields;

class Radio extends AbstractField
{
    public $options;
    public $path_view = 'fields/radio.php';

    public function __construct()
    {
    }
}
