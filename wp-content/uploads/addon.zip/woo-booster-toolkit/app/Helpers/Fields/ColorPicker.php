<?php

namespace WCBT\Helpers\Fields;

/**
 * ColorPicker
 */
class ColorPicker extends AbstractField {
	public $path_view = 'fields/color-picker.php';
	public function __construct() {
	}
}
