<?php

namespace WCBT\Helpers\Fields;

/**
 * Class WPEditor
 * @package WCBT\Helpers\AbstractForm
 */
class WPDropDownUser extends AbstractField
{
    public $path_view = 'fields/wp-dropdown-user.php';
    public $args;
    public function __construct()
    {
    }
}
